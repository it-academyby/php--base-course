<?php
error_reporting(E_ALL);
session_start();

define('TPL_DIR', 'tpl');

require_once(__DIR__ . DIRECTORY_SEPARATOR . "functions.php");