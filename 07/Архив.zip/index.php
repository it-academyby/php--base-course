<?php

require_once('inc/inc.php');

$pageTpl = getTemplate('page');
$form = getTemplate('form');
$msg = "";

$formData = getFormData();

if(isFormSubmitted()){
    $validateFormResult = isFormVaild($formData);
    if($validateFormResult!== true) {
        $form = processTemplateErrorOutput($form, $validateFormResult);
    } else {
        if(saveMessage($formData)){
            header('Location: '.$_SERVER['REQUEST_URI']);
            die;
        } else {
            $msg = 'Ошибка сохранения';
        }

    }
}

$form = processTemplace($form, $formData);
$form = processTemplace($form, array('CAPTCHA' => generateCaptcha()));

$page = processTemplace($pageTpl, array(
    'FORM' => $form,
    'MSG' => $msg
));

echo $page;