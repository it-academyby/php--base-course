<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Catalog Demo</title>
    <link rel="stylesheet" href="catalog.css"/>
</head>
<body>
<?php

define('PAGE_SIZE', 6);

function getPageSize($catalogMarker = ''){
    if(isset($_GET['pageSize'.$catalogMarker])){
        return (int)$_GET['pageSize'.$catalogMarker];
    } else {
        return PAGE_SIZE;
    }
}

function getCurrentPage($catalogMarker = ''){
    if(isset($_GET['pageNumber'.$catalogMarker])){
        return (int)$_GET['pageNumber'.$catalogMarker];
    } else {
        return 1;
    }
}

function getItemHtml($item){
    return '<strong>'.$item['title'].'</strong>'.'<p>'.$item['descr'].'</p>';
}

function _getStorage(){
    $arr = file('db.txt', FILE_IGNORE_NEW_LINES);
    $ret = array();
    foreach($arr as $row) {
        $tmp = explode('|', $row);
        $ret[] = array('title'=>$tmp[0],'descr'=>$tmp[1],'cost'=>$tmp[2]);
    }
    return $ret;
}

function getStorageSize(){
    return count(_getStorage());
}

function getItemsForPage($pageNum, $pageSize = PAGE_SIZE){
    $arr = _getStorage();
    $ret = array_slice($arr, ($pageNum - 1) * $pageSize, $pageSize);
    return $ret;
}

function getSizeSelectorHtml($url, $catalogMarker = '', $size = 10) {
    $html = "<form action='$url'>";
    foreach ($_GET as $key => $value) {
        $html .= "<input type='hidden' name='$key' value='$value'/>";
    }
    $listOfSizes = array(10, 20, 30);
    if(!in_array($size, $listOfSizes)){
        array_unshift($listOfSizes, $size);
    }
    $html .= '<select name=\'pageSize'.$catalogMarker.'\' onchange=\'this.form.submit();\'>';
    foreach($listOfSizes as $val) {
        $html .= '<option ';
        if($val == $size) {
            $html .= 'selected';
        }
        $html .= ">$val</option>";
    }
    $html .= '</select>';

    $html .= '</form>';
    return $html;
}

function getPaginatorHtml($pageNumber, $pageCount, $catalogMarker = ''){
    $getParams = $_GET;
    $html = '<ul class="catalog-paginator">';
    for($i = 1; $i<= $pageCount; $i++) {
        if($i == $pageNumber){
            $html .= '<li><strong>'.$i.'</strong>';
        } else {
            $getParams['pageNumber'.$catalogMarker] = $i;
            $link = http_build_query($getParams);
            $html .= '<li><a href="?'.$link.'">'.$i.'</a>';
        }
    }
    $html .= '</ul>';

    // select size block
    $pageSize = getPageSize($catalogMarker);
    $getParams['pageNumber'.$catalogMarker] = $pageNumber;
    $link = '?'.http_build_query($getParams);

    $html .= getSizeSelectorHtml($link, $catalogMarker, $pageSize);
    return $html;
}

function getPageCount($itemsCount, $perPage) {
    $val = $itemsCount / $perPage;
    if((int)$val < $val){
        $val = (int)$val + 1;
    }
    return $val;
}

function getPageHtml($pageNum, $pageSize = PAGE_SIZE) {
    $html = '<div class="catalog-page">';
    $items = getItemsForPage($pageNum, $pageSize);
    $html .= '<ul class="catalog-items-list">';
    foreach($items as $item){
        $html .= '<li>'.getItemHtml($item).'</li>';
    }
    $html .= '</ul>';
    $html .= '</div>';

    return $html;
}

function getCatalogHtml() {
    static $catalogNumber = 0;
    $catalogNumber++;

    $pageNum = getCurrentPage($catalogNumber);
    $pageSize = getPageSize($catalogNumber);
    $numOfItems = getStorageSize();

    $numOfPages = getPageCount($numOfItems, $pageSize);

    $html = "<div class=\"catalog catalog-$catalogNumber\">";
    $html .= getPageHtml($pageNum, $pageSize);
    $html .= getPaginatorHtml($pageNum, $numOfPages, $catalogNumber);
    $html .= '</div>';
    return $html;
}

echo getCatalogHtml();
echo getCatalogHtml();
echo getCatalogHtml();

?>
</body>
</html>
