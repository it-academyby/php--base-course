<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Catalog Demo</title>
    <link rel="stylesheet" href="catalog.css"/>
</head>
<body>
<?php

define('PAGE_SIZE', 6);

function getCurrentPage(){
    if(isset($_GET['pageNumber'])){
        return (int)$_GET['pageNumber'];
    } else {
        return 1;
    }
}

function getItemHtml($item){
    return '<strong>'.$item['title'].'</strong>'.'<p>'.$item['descr'].'</p>';
}

function _getStorage(){
    $arr = file('db.txt', FILE_IGNORE_NEW_LINES);
    $ret = array();
    foreach($arr as $row) {
        $tmp = explode('|', $row);
        $ret[] = array('title'=>$tmp[0],'descr'=>$tmp[1],'cost'=>$tmp[2]);
    }
    return $ret;
}

function getStorageSize(){
    return count(_getStorage());
}

function getItemsForPage($pageNum, $pageSize = PAGE_SIZE){
    $arr = _getStorage();
    $ret = array_slice($arr, ($pageNum - 1) * $pageSize, $pageSize);
    return $ret;
}

function getPaginatorHtml($pageNumber, $pageCount, $linkPattern = '?pageNumber={{NUM}}'){
    $html = '<ul class="catalog-paginator">';
    for($i = 1; $i<= $pageCount; $i++) {
        if($i == $pageNumber){
            $html .= '<li><strong>'.$i.'</strong>';
        } else {
            $html .= '<li><a href="'.str_replace('{{NUM}}', $i, $linkPattern).'">'.$i.'</a>';
        }
    }
    $html .= '</ul>';
    return $html;
}

function getPageCount($itemsCount, $perPage) {
    $val = $itemsCount / $perPage;
    if((int)$val < $val){
        $val = (int)$val + 1;
    }
    return $val;
}

function getPageHtml($pageNum, $pageSize = PAGE_SIZE) {
    $html = '<div class="catalog-page">';
    $items = getItemsForPage($pageNum, $pageSize);
    $html .= '<ul class="catalog-items-list">';
    foreach($items as $item){
        $html .= '<li>'.getItemHtml($item).'</li>';
    }
    $html .= '</ul>';
    $html .= '</div>';

    return $html;
}

function getCatalogHtml() {
    $pageNum = getCurrentPage();
    $numOfItems = getStorageSize();
    $numOfPages = getPageCount($numOfItems, PAGE_SIZE);

    $html = '<div class="catalog">';
    $html .= getPageHtml($pageNum, PAGE_SIZE);
    $html .= getPaginatorHtml($pageNum, $numOfPages);
    $html .= '</div>';
    return $html;
}

echo getCatalogHtml();

?>
</body>
</html>
