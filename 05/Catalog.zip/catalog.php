<?php

define('PAGE_SIZE', 6);

function getCurrentPage(){
    if(isset($_GET['pageNumber'])){
        return (int)$_GET['pageNumber'];
    } else {
        return 1;
    }
}

function getItemHtml($item){
    return '<h3>'.$item['title'].'</h3>'.'<p>'.$item['descr'].'</p>'.'<p>'.$item['cost'].'</p>';
}

function _getStorage(){
    $arr = file('db.txt', FILE_IGNORE_NEW_LINES);
    $ret = array();
    foreach($arr as $row) {
        $tmp = explode('|', $row);
        $ret[] = array('title'=>$tmp[0],'descr'=>$tmp[1],'cost'=>$tmp[2]);
    }
    return $ret;
}

function getStorageSize(){
    return count(_getStorage());
}

function getItemsForPage($pageNum, $pageSize = PAGE_SIZE){
    $arr = _getStorage();
    $ret = array_slice($arr, ($pageNum - 1) * $pageSize, $pageSize);
    return $ret;
}

function getPaginatorHtml($pageNumber, $pageCount, $linkPattern = '?pageNumber={{NUM}}'){
    $html = '<ul>';
    for($i = 1; $i<= $pageCount; $i++) {
        $html .= '<li><a href="'.str_replace('{{NUM}}', $i, $linkPattern).'">'.$i.'</a>';
    }
    $html .= '</ul>';
    return $html;
}

function getPageCount($itemsCount, $perPage) {
    $val = $itemsCount / $perPage;
    if((int)$val < $val){
        $val = (int)$val + 1;
    }
    return $val;
}

$pageNum = getCurrentPage();
$numOfItems = getStorageSize();
$numOfPages = getPageCount($numOfItems, PAGE_SIZE);

$items = getItemsForPage($pageNum, PAGE_SIZE);

echo '<ul>';
foreach($items as $item){
    echo getItemHtml($item);
}
echo '</ul>';

echo getPaginatorHtml($pageNum, $numOfPages);